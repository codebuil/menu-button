package button.menu;

import android.app.Activity;
import android.os.Bundle;

import android.app.*;
import android.os.*;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.view.KeyEvent.Callback;
import	android.view.KeyEvent;
import android.view.MenuInflater;
import 	android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.ViewConfiguration;

import android.content.ContextWrapper;
import android.view.ContextThemeWrapper;

import android.content.Context;



public class MainActivity extends Activity
{
private Context context;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        context=this;
    }
	public void  onmenu1_click(View v) {
		setTitle("menu1");
		System.setProperty("menu1","1");

					try{
						Intent intent = new Intent(context,MainActivity1.class);

						startActivity(intent);  

						finish(); 
					}catch(Exception e){}

				
	} 
	public void onmenu2_click(View v) {
		setTitle("menu2");
		System.setProperty("menu2","2");

					try{
						Intent intent = new Intent(context,MainActivity2.class);

						startActivity(intent);  

						finish(); 
					}catch(Exception e){}

	}
	public void onmenu3_click(View v) {
		setTitle("menu3");
		System.setProperty("menu3","3");

					try{
						Intent intent = new Intent(context,MainActivity3.class);

						startActivity(intent);  

						finish(); 
					}catch(Exception e){}

	}
	public void onmenu4_click(View v) {
		setTitle("menu4");
		System.setProperty("menu4","4");

					try{
						Intent intent = new Intent(context,MainActivity4.class);

						startActivity(intent);  

						finish(); 
					}catch(Exception e){}

	}
	public void onmenu5_click(View v) {
		setTitle("menu5");
		System.setProperty("menu5","5");

					try{
						Intent intent = new Intent(context,MainActivity5.class);

						startActivity(intent);  

						finish(); 
					}catch(Exception e){}

	}
	public void onmenu6_click(View v) {
		setTitle("menu6");
		System.setProperty("menu6","6");

					try{
						Intent intent = new Intent(context,MainActivity6.class);

						startActivity(intent);  

						finish(); 
					}catch(Exception e){}

	}
	public void onmenu7_click(View v) {
		setTitle("menu7");
		System.setProperty("menu7","7");

					try{
						Intent intent = new Intent(context,MainActivity7.class);

						startActivity(intent);  

						finish(); 
					}catch(Exception e){}

	}
	public void onmenu8_click(View v) {
		setTitle("menu8");
		System.setProperty("menu8","8");

					try{
						Intent intent = new Intent(context,MainActivity8.class);

						startActivity(intent);  

						finish(); 
					}catch(Exception e){}

	}
	public void onmenu9_click(View v) {
		setTitle("menu9");
		System.setProperty("menu9","9");

					try{
						Intent intent = new Intent(context,MainActivity9.class);

						startActivity(intent);  

						finish(); 
					}catch(Exception e){}

	}
	public void onmenu10_click(View v) {
		setTitle("menu10");
		System.setProperty("menu10","10");

					try{
						Intent intent = new Intent(context,MainActivity10.class);

						startActivity(intent);  

						finish(); 
					}catch(Exception e){}

	}
}

